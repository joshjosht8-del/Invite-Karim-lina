# Invitation de mariage digitale — Lina & Karim

Site à page unique, avec enveloppe animée à cliquer, musique de fond, compte à rebours, programme, lieu et RSVP.

## Personnaliser pour un nouveau client

Tout se change à deux endroits :

**1. `script.js` → objet `CONFIG` en haut du fichier**
- `names` / `initials` — prénoms et monogramme du cachet
- `weddingDateISO` — date et heure exactes (utilisées par le compte à rebours)
- `venue` — nom, adresse, ville pour la carte
- `music.src` — chemin du fichier audio
- `formspreeEndpoint` — l'URL de votre formulaire Formspree

**2. `index.html`**
- Prénoms dans `.hero-names`, date dans `.hero-date`, initiales dans `.wax-seal__initials` et `.footer-monogram`
- Texte d'introduction dans `#invocation`
- Programme (`#schedule`) : modifiez les 4 `<li class="timeline-item">`
- Lieu (`#venue`) : adresse + `src` de l'iframe Google Maps (remplacez `Alger` par votre ville/adresse)
- Tenue, cadeaux, enfants dans `.panel--details`

## Musique

Déposez votre fichier dans `assets/theme-song.mp3` (non fourni ici pour des raisons de droits d'auteur — utilisez un morceau libre de droits ou une licence achetée, par exemple sur Epidemic Sound, Artlist ou Pixabay Music). Le site lance la musique automatiquement au moment où l'invité clique sur le cachet de cire (les navigateurs bloquent l'autoplay sans interaction, donc le déclenchement au clic est le plus fiable).

## RSVP

Créez un formulaire gratuit sur [formspree.io](https://formspree.io), copiez l'URL `https://formspree.io/f/XXXXXXX` et remplacez `VOTRE_ID_FORMSPREE` dans `index.html` (attribut `action`) **et** dans `script.js` (`CONFIG.formspreeEndpoint`).

## Mise en ligne (gratuit, GitHub Pages)

1. Créez un dépôt GitHub, ajoutez ces fichiers (`index.html`, `style.css`, `script.js`, `assets/`)
2. Settings → Pages → Source : branche `main`, dossier `/root`
3. Le site est en ligne sur `https://votrenom.github.io/votre-depot/`
4. Domaine personnalisé possible gratuitement via Settings → Pages → Custom domain

## Détails techniques

- Aucune dépendance : HTML/CSS/JS pur, aucun framework, aucune build step
- Polices : Google Fonts (Playfair Display, Cormorant Garamond, Alex Brush)
- Accessibilité : focus visible, `prefers-reduced-motion` respecté, cachet activable au clavier
- Compatible mobile en priorité (le format visé pour vos clients)
